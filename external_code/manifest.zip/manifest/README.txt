See link for instructions:

http://rd.beijerelectronics.com/software/SitePages/Yocto.aspx

Further and latest instructions are in 'June-2019-documentation-v3.txt'
