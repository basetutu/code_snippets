#!/usr/bin/env python
import itertools
import threading
import subprocess
import evdev
import evdev.ecodes as ec
import xtest
from select import select


xconn = None


class ActionKey:
    def __init__(self, string):
        self.string = string

    def __call__(self, *args, **kwargs):
        xconn.fakeKeyEvent(self.string)


class ActionScript:
    def __init__(self, command):
        self.command = command

    def __call__(self, *args, **kwargs):
        subprocess.call(self.command)


class HoldSecs:
    def __init__(self, action, seconds):
        self.seconds=seconds
        self.timer = None
        self.action = action

    def __call__(self, value=None):
        if value == 0 and self.timer is not None:
            self.timer.cancel()
            self.timer = None
        if value == 1 and self.timer is None:
            self.timer = threading.Timer(self.seconds, self.activate)
            self.timer.start()

    def activate(self):
        self.action()


class EvdevWatcher:
    def __init__(self, rules):
        self.rules = rules
        self.devices = []
        alldevices = [evdev.InputDevice(fn) for fn in evdev.list_devices()]
        for device in alldevices:
            cap = device.capabilities()
            if ec.EV_KEY in cap and ec.BTN_TOUCH in cap[ec.EV_KEY]:
                self.devices.append(device)

    def handle(self, fd):
        for event in fd.read():
            for rule in self.rules:
                if event.type == rule[0] and event.code == rule[1]:
                    self.rules[rule](value=event.value)

    def get_list(self):
        return self.devices, [], []


class MountWatcher:
    def __init__(self, rules):
        self.rules = rules
        self.mfile = [open("/proc/mounts")]

    def handle(self, fd):
        fd.seek(0)
        for mount in fd.readlines():
            for rule in self.rules:
                if rule in mount:
                    self.rules[rule]()

    def get_list(self):
        return [], [], self.mfile


class Master:
    def __init__(self):
        self.rlist = []
        self.wlist = []
        self.xlist = []
        self.handlers = {}

    def watch(self):
        while True:
            res = select(self.rlist, self.wlist, self.xlist)
            for fd in itertools.chain.from_iterable(res):
                self.handlers[fd].handle(fd)

    def add_fds(self, watcher):
        res = watcher.get_list()
        for f in itertools.chain.from_iterable(res):
            self.handlers[f] = watcher
        self.rlist.extend(res[0])
        self.wlist.extend(res[1])
        self.xlist.extend(res[2])


def main():
    global xconn
    xconn = xtest.XTest()

    m = Master()
    evrules = {(ec.EV_KEY, ec.BTN_TOUCH): HoldSecs(ActionKey("Alt-Home"), seconds=5.0)}
    m.add_fds(EvdevWatcher(evrules))
    mountrules = {"/var/usbstore": ActionScript(["beijer-installer.py", "--mode", "update", "/var/usbstore"])}
    m.add_fds(MountWatcher(mountrules))
    m.watch()


if __name__ == "__main__":
    main()
