#!/bin/bash

set -e
set -x
set -o pipefail

updatefile=$1
updateboot=$2
updateroot=$3
updateuboot=$4

if [ ! -f "$updatefile" ]; then
    echo -e "\n\n - ERROR: Missing updatefile: $updatefile - \n\n"
    sleep 1; exit 1
fi

rootpart=3
if grep -q "root=/dev/mmcblk1p3" /proc/cmdline; then
    rootpart=2
elif grep -q "root=/dev/mmcblk1p2" /proc/cmdline; then
    rootpart=3
else
    echo -e "\n\n - ERROR: Unknown setup! - \n\n"
    sleep 1; exit 1
fi

mkdir -p /run/media/target-boot
mkdir -p /run/media/source-boot

# Update boot
if [ "$updateboot" = "1" ]; then
    tar -Oxf "$updatefile" boot.img > "$HOME/boot.img"
    mount -o ro,loop "$HOME/boot.img" /run/media/source-boot
    mount /dev/mmcblk1p1 /run/media/target-boot

    cp -dR /run/media/source-boot/* /run/media/target-boot/

    umount /run/media/source-boot/
    umount /run/media/target-boot/
fi

# Update root
if [ "$updateroot" = "1" ]; then
    tar -Oxf "$updatefile" root.img | dd of="/dev/mmcblk1p$rootpart" bs=16M status=progress oflag=direct iflag=fullblock
    mount /dev/mmcblk1p1 /run/media/target-boot
    echo "rootpart=$rootpart" > /run/media/target-boot/uEnv.txt
    umount /run/media/target-boot/
fi

# Update bootloader
if [ "$updateuboot" = "1" ]; then
    tar -Oxf "$updatefile" u-boot.imx > "$HOME/u-boot.imx"
    dd if="$HOME/u-boot.imx" of=/dev/mtdblock0 seek=1024 bs=16M status=progress oflag=direct,seek_bytes
fi

# DONE!

echo -e "\n\n - DONE - \n\nRemove USB Stick and reboot\n\n"
sleep 1
