#!/usr/bin/env python
import gi, os
import os.path
import subprocess
import argparse
import threading
import tarfile
import hashlib
import gpgme
gi.require_version('Gtk', '3.0')
gi.require_version('Vte', '2.91')
from gi.repository import Gtk, Gdk, Vte, GObject
from gi.repository import GLib


def get_root_version():
    try:
        with open("/etc/version") as vfile:
            v = vfile.next().strip()
            if v:
                return v
    except:
        pass


class UpdateParseError(Exception):
    """Raised when update parsing fails"""


def md5sum(f):
    hash = hashlib.md5()
    buf = f.read(65536)
    while len(buf) > 0:
        hash.update(buf)
        buf = f.read(65536)
    return hash.hexdigest()


def parse_manifest(mfile):
    m = {}
    v = mfile.readline().strip()
    for line in mfile:
        parts = line.split()
        if len(parts) == 2:
            m[parts[1]] = parts[0]
    return v, m


def update_decrypt(updatepath):
    c = gpgme.Context()
    c.set_engine_info(0, None, "/opt/beijer-key/")
    with open(updatepath, 'rb') as input_file:
        with open("/tmp/update.tar", 'wb') as output_file:
            ret = c.verify(input_file, None, output_file)
            for sig in ret:
                if sig.status:
                    print sig.status
                    raise UpdateParseError("Invalid signature")
    return "/tmp/update.tar"


def get_update(updatepath):
    if not updatepath:
        raise UpdateParseError("No update path provided")
    try:
        if os.path.isdir(updatepath):
            updatefiles = [x for x in os.listdir(updatepath) if x.endswith(".supdate")]
            if len(updatefiles) > 1:
                raise UpdateParseError("Found more than one update")
            elif len(updatefiles) == 0:
                raise UpdateParseError("No update file found")
            updatepath = os.path.join(updatepath, updatefiles[0])

        real_update = update_decrypt(updatepath)

        u = {"file": real_update,
             "updateitems": []}
        with tarfile.TarFile(real_update, format="r|") as f:
            version, manifest = parse_manifest(f.extractfile("update.manifest"))
            u["version"] = version
            for ufile, manifest_md5 in manifest.items():
                u["updateitems"].append(ufile)
    except UpdateParseError:
        raise
    except Exception, err:
        raise UpdateParseError("Unexpected error:\n" + str(err))

    return u


class MaintUi(Gtk.Window):
    def __init__(self, mode="install", debug=False, updatepath=None):
        self.debug = debug
        self.mode = mode
        self.updatepath = updatepath
        self.update = None
        self.update_error = None
        self.root_version = "unknown"
        Gtk.Window.__init__(self, name="window", title="Secure Software Installer", decorated=False)
        self.set_size_request(1024, 768)

        style_provider = Gtk.CssProvider()
        style_provider.load_from_data("#window { font-size: 300%; }")
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            style_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

        self.main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(self.main_box)

        label = Gtk.Label("Secure Software Installer")
        self.main_box.pack_start(label, False, False, 0)

        self.grid = Gtk.Grid(orientation=Gtk.Orientation.HORIZONTAL)
        self.grid.set_column_homogeneous(True)
        self.grid.set_row_homogeneous(True)
        self.main_box.pack_start(self.grid, True, True, 0)

        self.bottom_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.bottom_box.set_homogeneous(True)
        self.main_box.pack_start(self.bottom_box, True, True, 0)

        self.install_button = Gtk.Button(label="Install")
        self.install_button.connect("clicked", self.install)
        self.install_button.set_property("margin", 10)
        self.install_button.set_sensitive(False)
        self.grid.attach(self.install_button, 0, 0, 1, 1)

        if self.mode == "update":
            self.info = Gtk.Label("Verifying signature...")
        else:
            self.info = Gtk.Label("Reading information...")
        self.info.set_property("margin", 10)
        self.info.set_line_wrap(True)
        self.grid.attach(self.info, 1, 0, 1, 1)

        b = Gtk.Button(label="Reboot")
        b.connect("clicked", self.reboot)
        b.set_property("margin", 10)
        self.bottom_box.pack_start(b, True, True, 0)

        b = Gtk.Button(label="Poweroff")
        b.connect("clicked", self.poweroff)
        b.set_property("margin", 10)
        self.bottom_box.pack_start(b, True, True, 0)

        self.connect("delete-event", Gtk.main_quit)
        self.show_all()
        threading.Thread(target=self.do_parse).start()

    def reboot(self, *args):
        if self.debug:
            Gtk.main_quit()
        else:
            if self.mode == "update":
                subprocess.call(["reboot"])
            else:
                subprocess.call(["reboot", "-f", "-d", "-n"])

    def poweroff(self, *args):
        if self.debug:
            Gtk.main_quit()
        else:
            if self.mode == "update":
                subprocess.call(["poweroff"])
            else:
                subprocess.call(["poweroff", "-f", "-d", "-n"])

    def do_parse(self, *args):
        # Root version
        v = get_root_version()
        if v:
            self.root_version = v

        # Update version
        if self.mode == "update":
            try:
                self.update = get_update(self.updatepath)
            except Exception as err:
                self.update_error = err

        GLib.idle_add(self.parsing_complete)

    def parsing_complete(self):
        if self.mode == "install":
            self.info.set_text("Version:\n%s" % self.root_version)
            self.install_button.set_sensitive(True)
        elif self.mode == "update":
            if self.update_error is not None:
                self.info.set_text(str(self.update_error))
            else:
                s = "Old version:\n%s\nNew version:\n%s" % (self.root_version, self.update["version"])
                self.info.set_text(s)
                self.install_button.set_sensitive(True)
        else:
            print "ERROR: Unknown mode"

    def install(self, button):
        if self.debug:
            process = ["top"]
        elif self.mode == "install":
            process = ["beijer-install.sh"]
        else:
            bootflag = "1" if "boot.img" in self.update["updateitems"] else "0"
            rootflag = "1" if "root.img" in self.update["updateitems"] else "0"
            ubootflag = "1" if "u-boot.imx" in self.update["updateitems"] else "0"
            process = ["beijer-update.sh", self.update["file"], bootflag, rootflag, ubootflag]

        for x in self.grid.get_children():
            self.grid.remove(x)

        terminal = Vte.Terminal()
        terminal.spawn_sync(
            Vte.PtyFlags.DEFAULT,
            os.environ['HOME'],
            process,
            [],
            GLib.SpawnFlags.SEARCH_PATH_FROM_ENVP,
            None,
            None,
        )

        self.grid.attach(terminal, 0, 0, 2, 2)
        terminal.show()


def main():
    os.environ["PATH"] += ":/sbin:/usr/sbin"
    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--mode", default="install", choices=["install", "update"])
    parser.add_argument("updatepath", nargs="?", default="")
    args = vars(parser.parse_args())

    GObject.threads_init()

    app = MaintUi(**args)
    Gtk.main()


if __name__ == "__main__":
    main()
