#!/bin/bash

CALFILE=/var/storage/calibration.xinput
CALDATA=`cat $CALFILE`

if [ "$1" == "--force" -o "$CALDATA" == "" ]; then
    CALDATA=`xinput_calibrator --output-type xinput | sed -n "s/xinput set-int-prop//p"`
    if [ "$CALDATA" != "" ]; then
        echo "$CALDATA" > "$CALFILE"
        sync
    fi
else
    echo "$CALDATA" | while read -r argline; do
        eval "CALARGS=( $argline )"
        xinput set-int-prop "${CALARGS[@]}"
    done
fi
