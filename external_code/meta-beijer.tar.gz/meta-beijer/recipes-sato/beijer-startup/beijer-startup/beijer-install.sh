#!/bin/bash

set -e
set -x
set -o pipefail

/etc/init.d/connman stop || true

while mount | grep -q /var/storage; do
    umount /var/storage || true
    sleep 1
done

# Copy bootloader
dd if=/boot/u-boot.imx of=/dev/mtdblock0 seek=1024 bs=16M status=progress oflag=direct,seek_bytes

# Create partitions
echo "o
n
p
1

+9M
n
p
2

+500M
n
p
3

+500M
n
p
4


p
w" | fdisk /dev/mmcblk1

# Create storage filesystem
mkfs.ext4 -F /dev/mmcblk1p4

# Copy filesystems
dd if=/dev/mmcblk0p1 of=/dev/mmcblk1p1 bs=16M status=progress oflag=direct
dd if=/dev/mmcblk0p2 of=/dev/mmcblk1p2 bs=16M status=progress oflag=direct

# DONE!

echo -e "\n\n - DONE - \n\nCut power, remove SDCard and flip boot switches\n\n"
sleep 1
