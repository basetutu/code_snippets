#!/bin/bash
UPDATEFILES=`ls /var/usbstore/*.supdate 2> /dev/null`

# Select UI
if grep -q "root=/dev/mmcblk0p2" /proc/cmdline; then
    # Installer UI
    beijer-installer.py --mode install
elif [ -n "$UPDATEFILES" ]; then
    # Update UI
    beijer-installer.py --mode update /var/usbstore/
else
    # We should block on this script first
    beijer-calibrate.sh

    # Start session services with forking
    if [ -d /opt/beijer-startup.d ]; then
        for i in /opt/beijer-startup.d/*; do
            $i &
        done
        unset i
    fi
fi
