#!/usr/bin/env python
import gi, os
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GObject
from gi.repository import GLib
from subprocess import Popen, PIPE
import fcntl

window = Gtk.Window()
window.set_default_size(800, 400)
window.set_decorated(False)
window.connect("destroy", Gtk.main_quit)
#textview = Gtk.TextView()
#scroll = Gtk.ScrolledWindow()
#scroll.add(textview)
#exp = Gtk.Expander()
#exp.add(scroll)
#window.add(exp)
grid = Gtk.Grid()
grid.set_row_spacing(18)
grid.set_column_spacing(18)
button = Gtk.Button(label="Close")
Gtk.Widget.set_size_request(button, 120, 40)
button.connect("clicked", Gtk.main_quit)
label = Gtk.Label()
label.set_alignment(0, 0)
grid.attach(button, 1, 3, 1, 2)
grid.attach(label, 1, 0, 3, 3)
window.add(grid)

window.show_all()
sub_proc = Popen("ifconfig eth0", stdout=PIPE, shell=True)
sub_outp = ""

def non_block_read(output):
		fd = output.fileno()
		fl = fcntl.fcntl(fd, fcntl.F_GETFL)
		fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)
		try:
			return output.read()
		except:
			return ''


def update_terminal():
	#textview.get_buffer().insert_at_cursor(non_block_read(sub_proc.stdout))
	label.set_text(label.get_text() + non_block_read(sub_proc.stdout))
	return sub_proc.poll() is None

GObject.timeout_add(100, update_terminal)
Gtk.main()

