#!/bin/sh
matchbox-keyboard -d beijer &
