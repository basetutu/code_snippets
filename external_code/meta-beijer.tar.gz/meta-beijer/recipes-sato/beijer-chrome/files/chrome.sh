#!/bin/sh

TOUCHDEV=`xinput_calibrator --list | cut -d = -f 2`

CLEAN_INTERFACE="--kiosk --disable-infobars --disable-translate --no-first-run --no-default-browser-check \
--disable-app-window-cycling --disable-tab-switcher --disable-extensions"

# Also for performance reasons
PRIVACY="--no-pings --disable-gaia-services --disable-breakpad --disable-sync --no-proxy-server"

PERFORMANCE="--num-raster-threads=2"

TOUCH="--disable-touch-drag-drop --disable-pinch --touch-noise-filtering --touch-events --overscroll-history-navigation=2"

while true; do
    google-chrome http://localhost:8080/ $CLEAN_INTERFACE $PRIVACY $PERFORMANCE $TOUCH --touch-devices="$TOUCHDEV"
    sleep 1
done
